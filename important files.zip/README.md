# chronic-kidney-disease-prediction

install all requirements 
pip install -r requirements.txt
